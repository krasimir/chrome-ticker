Chrome-Ticker
=============

Chrome extension which replaces the boring new-tab page. It shows the current time and different programming quote on every refresh.

![Chrome-Ticker](http://work.krasimirtsonev.com/git/chrome-ticker/screenshot.jpg)
